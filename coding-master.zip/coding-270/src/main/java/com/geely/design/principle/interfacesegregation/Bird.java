package com.geely.design.principle.interfacesegregation;

/**
 * Created by geely
 */
public class Bird implements IAnimalAction {
    @Override
    public void eat() {

    }

    @Override
    public void fly() {

    }

    @Override
    public void swim() {

    }
}
