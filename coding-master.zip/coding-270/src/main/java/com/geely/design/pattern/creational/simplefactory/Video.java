package com.geely.design.pattern.creational.simplefactory;

/**
 * Created by geely
 */
public abstract class Video {
    public abstract void produce();

}
