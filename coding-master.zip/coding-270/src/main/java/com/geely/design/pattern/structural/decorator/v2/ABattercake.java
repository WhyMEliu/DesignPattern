package com.geely.design.pattern.structural.decorator.v2;

/**
 * Created by geely
 */
public abstract class ABattercake {
    protected abstract String getDesc();
    protected abstract int cost();

}
