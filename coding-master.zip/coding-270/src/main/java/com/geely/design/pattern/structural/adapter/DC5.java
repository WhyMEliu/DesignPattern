package com.geely.design.pattern.structural.adapter;

/**
 * Created by geely
 */
public interface DC5 {
    int outputDC5V();
}
