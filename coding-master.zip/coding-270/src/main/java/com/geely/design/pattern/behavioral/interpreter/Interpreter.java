package com.geely.design.pattern.behavioral.interpreter;

/**
 * Created by geely.
 */
public interface Interpreter {
    int interpret();
}
