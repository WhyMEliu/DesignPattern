package com.geely.design.pattern.behavioral.command;

/**
 * Created by geely
 */
public interface Command {
    void execute();
}
