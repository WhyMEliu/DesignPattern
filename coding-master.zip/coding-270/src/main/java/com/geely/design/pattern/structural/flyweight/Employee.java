package com.geely.design.pattern.structural.flyweight;

/**
 * Created by geely
 */
public interface Employee {
    void report();
}
